package org.firstinspires.ftc.teamcode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;


@TeleOp

public class GripLiftOpMode extends LinearOpMode {
   private DcMotor gripLift = null; 
   @Override
   public void runOpMode() throws InterruptedException {

      // Position of the arm when it's lifted
      int gripLiftUpPosition = 10000;

      // Position of the arm when it's down
      int gripLiftDownPosition = 0;

      // Find a motor in the hardware map named "Arm Motor"
      DcMotor gripLift = hardwareMap.dcMotor.get("gripLift");

      // Reset the motor encoder so that it reads zero ticks
      gripLift.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

      // Sets the starting position of the arm to the down position
      gripLift.setTargetPosition(gripLiftDownPosition);
      gripLift.setMode(DcMotor.RunMode.RUN_TO_POSITION);

      waitForStart();

      while (opModeIsActive()) {
            // If the A button is pressed, raise the arm
            if (gamepad1.a) {
               gripLift.setTargetPosition(gripLiftUpPosition);
               gripLift.setMode(DcMotor.RunMode.RUN_TO_POSITION);
               gripLift.setPower(0.5);
            }

            // If the B button is pressed, lower the arm
            if (gamepad1.b) {
               gripLift.setTargetPosition(gripLiftDownPosition);
               gripLift.setMode(DcMotor.RunMode.RUN_TO_POSITION);
               gripLift.setPower(0.5);
            }

            // Get the current position of the armMotor
            double position = gripLift.getCurrentPosition();

            // Get the target position of the armMotor
            double desiredPosition = gripLift.getTargetPosition();

            // Show the position of the armMotor on telemetry
            telemetry.addData("Encoder Position", position);

            // Show the target position of the armMotor on telemetry
            telemetry.addData("Desired Position", desiredPosition);

            telemetry.update();
      }
   }
}
